<?php
$sum = 2007 + 8 - 27;
$fio = 'Глеб' . 'Шестопалов';
$length = 27 * 2;
$width = 8 + 7;
$square = $length  * $width;

echo "Результат сложения трех чисел: " . $sum . "\n";
echo "Меня зовут: " . $fio . "\n";
echo "Результат площади: " . $square . "\n";
?>