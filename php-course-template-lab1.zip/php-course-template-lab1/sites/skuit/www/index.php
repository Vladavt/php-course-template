<? 
include_once './lab1/hello_php.php';
?>